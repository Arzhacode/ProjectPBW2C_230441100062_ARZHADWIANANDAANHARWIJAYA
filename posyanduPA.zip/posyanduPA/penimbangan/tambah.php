<?php
session_start();
include "../db.php";

// Cek session ortu, jika tidak ada redirect ke login
if (!isset($_SESSION['ortu'])) {
  header("Location: ../login_ortu.php");
  exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id_anak = $_POST['id_anak'];
  $berat = $_POST['berat'];
  $tinggi = $_POST['tinggi'];
  $tgl = $_POST['tanggal'];

  // Bisa tambah validasi disini sebelum insert

  $stmt = $conn->prepare("INSERT INTO penimbangan (id_anak, berat_badan, tinggi_badan, tanggal) VALUES (?, ?, ?, ?)");
  $stmt->bind_param("idds", $id_anak, $berat, $tinggi, $tgl);
  $stmt->execute();
  $stmt->close();

  header("Location:data.php");
  exit;
}

// Ambil data anak sesuai ortu yang login
$nik_ortu = $_SESSION['ortu'];
$res = $conn->prepare("SELECT id_anak, nama_anak FROM anak WHERE nik_ortu = ?");
$res->bind_param("s", $nik_ortu);
$res->execute();
$result = $res->get_result();

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Tambah Penimbangan</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-4">
  <h2>Tambah Penimbangan</h2>
  <form method="post">
    <div class="mb-3">
      <select name="id_anak" class="form-control" required>
        <option value="">-- Pilih Anak --</option>
        <?php while ($a = $result->fetch_assoc()) : ?>
          <option value="<?= htmlspecialchars($a['id_anak']) ?>"><?= htmlspecialchars($a['nama_anak']) ?></option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="mb-3">
      <input type="number" step="0.1" name="berat" placeholder="Berat (kg)" class="form-control" required>
    </div>
    <div class="mb-3">
      <input type="number" step="0.1" name="tinggi" placeholder="Tinggi (cm)" class="form-control" required>
    </div>
    <div class="mb-3">
      <input type="date" name="tanggal" class="form-control" required>
    </div>
    <button class="btn btn-success">Simpan</button>
    <a href="data.php" class="btn btn-secondary">Batal</a>
  </form>
</div>
</body>
</html>
