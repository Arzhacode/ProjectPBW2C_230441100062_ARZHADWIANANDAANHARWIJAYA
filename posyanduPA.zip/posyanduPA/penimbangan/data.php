<?php
session_start();
include "../db.php";

if (!isset($_SESSION['ortu'])) {
    header("Location: ../login_ortu.php");
    exit;
}

$nik_ortu = $_SESSION['ortu'];

$sql = "SELECT id_anak, nama_anak FROM anak WHERE nik_ortu='$nik_ortu'";
$result = $conn->query($sql);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_anak = (int)$_POST['id_anak'];
    $berat = (float)$_POST['berat'];
    $tinggi = (float)$_POST['tinggi'];
    $tanggal = $_POST['tanggal'];

    $stmt = $conn->prepare("INSERT INTO penimbangan (id_anak, berat_badan, tinggi_badan, tanggal) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("idds", $id_anak, $berat, $tinggi, $tanggal);
    $stmt->execute();
    $stmt->close();

    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8" />
<title>Tambah Penimbangan</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
<style>
  body {
    background: linear-gradient(to right, #aed581, #4dd0e1);
    min-height: 100vh;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 2rem;
  }
  .form-container {
    background: #fff;
    padding: 2.5rem 3rem;
    border-radius: 1rem;
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
    max-width: 500px;
    width: 100%;
    animation: fadeIn 0.5s ease forwards;
  }
  @keyframes fadeIn {
    from {opacity: 0; transform: translateY(20px);}
    to {opacity: 1; transform: translateY(0);}
  }
  h2 {
    text-align: center;
    color: #2e7d32;
    margin-bottom: 1.8rem;
    font-weight: 700;
  }
  label {
    font-weight: 600;
  }
  .btn-success {
    background-color: #4caf50;
    border-color: #4caf50;
    font-weight: 600;
  }
  .btn-success:hover {
    background-color: #388e3c;
    border-color: #388e3c;
  }
  .btn-secondary {
    font-weight: 600;
  }
</style>
</head>
<body>

<div class="form-container">
  <h2><i class="fas fa-weight-scale me-2"></i>Tambah Penimbangan</h2>
  <form method="post" novalidate>
    <div class="mb-3">
      <label for="id_anak" class="form-label">Pilih Anak</label>
      <select id="id_anak" name="id_anak" class="form-select" required>
        <option value="">-- Pilih Anak --</option>
        <?php while($row = $result->fetch_assoc()): ?>
          <option value="<?= htmlspecialchars($row['id_anak']) ?>"><?= htmlspecialchars($row['nama_anak']) ?></option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="mb-3">
      <label for="berat" class="form-label">Berat Badan (kg)</label>
      <input type="number" step="0.1" name="berat" id="berat" class="form-control" required placeholder="Contoh: 10.5">
    </div>
    <div class="mb-3">
      <label for="tinggi" class="form-label">Tinggi Badan (cm)</label>
      <input type="number" step="0.1" name="tinggi" id="tinggi" class="form-control" required placeholder="Contoh: 75.3">
    </div>
    <div class="mb-3">
      <label for="tanggal" class="form-label">Tanggal Penimbangan</label>
      <input type="date" name="tanggal" id="tanggal" class="form-control" required>
    </div>
    <div class="d-flex justify-content-between">
      <button type="submit" class="btn btn-success"><i class="fas fa-save me-1"></i> Simpan</button>
      <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i> Batal</a>
    </div>
  </form>
</div>

</body>
</html>
