<?php
session_start();
include "../db.php";

// Ambil semua jadwal dari tabel jadwal
$res = $conn->query("SELECT * FROM jadwal ORDER BY tanggal DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Jadwal Posyandu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <style>
    body {
      background: linear-gradient(to right, #aed581, #4dd0e1);
      min-height: 100vh;
      font-family: 'Segoe UI', sans-serif;
      padding: 2rem 0;
    }
    .container-jadwal {
      background: #fff;
      padding: 2.5rem 3rem;
      border-radius: 1rem;
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
      max-width: 900px;
      margin: 2rem auto;
      animation: fadeIn 0.5s ease-in-out;
    }
    @keyframes fadeIn {
      from {opacity: 0; transform: translateY(15px);}
      to {opacity: 1; transform: translateY(0);}
    }
    h2 {
      color: #00695c;
      font-weight: bold;
      margin-bottom: 1.5rem;
      text-align: center;
    }
    .btn-primary {
      font-weight: 600;
    }
    .table thead {
      background-color: #4db6ac;
      color: #fff;
    }
    .table-hover tbody tr:hover {
      background-color: #f1f8e9;
    }
    .table td, .table th {
      text-align: center;
      vertical-align: middle;
    }
    .btn-group .btn {
      margin-right: 0.3rem;
    }
  </style>
</head>
<body>

<div class="container-jadwal">
  <h2><i class="fas fa-calendar-alt me-2"></i>Jadwal Posyandu</h2>
  <div class="mb-3 text-center">
    <a href="tambah.php" class="btn btn-success"><i class="fas fa-plus me-1"></i>Tambah Jadwal</a>
  </div>

  <table class="table table-bordered table-hover">
    <thead>
      <tr>
        <th><i class="fas fa-calendar-day"></i> Tanggal</th>
        <th><i class="fas fa-tasks"></i> Kegiatan</th>
        <th><i class="fas fa-cogs"></i> Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($res->num_rows > 0): ?>
        <?php while ($r = $res->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($r['tanggal']) ?></td>
            <td><?= htmlspecialchars($r['kegiatan']) ?></td>
            <td>
              <a href="edit.php?id_jadwal=<?= $r['id_jadwal'] ?>" class="btn btn-warning btn-sm text-white" title="Edit">
                <i class="fas fa-edit"></i>
              </a>
              <a href="hapus.php?id_jadwal=<?= $r['id_jadwal'] ?>" class="btn btn-danger btn-sm" title="Hapus" onclick="return confirm('Yakin ingin menghapus jadwal ini?')">
                <i class="fas fa-trash-alt"></i>
              </a>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr>
          <td colspan="3" class="text-center">Belum ada data jadwal.</td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>
