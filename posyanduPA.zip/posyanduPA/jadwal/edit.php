<?php
session_start();
include "../db.php";

if (!isset($_GET['id_jadwal']) || !is_numeric($_GET['id_jadwal'])) {
    die("ID jadwal tidak valid.");
}

$id = (int)$_GET['id_jadwal'];

// Ambil data jadwal
$stmt = $conn->prepare("SELECT * FROM jadwal WHERE id_jadwal = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$jadwal = $result->fetch_assoc();
$stmt->close();

if (!$jadwal) {
    die("Data jadwal tidak ditemukan.");
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tanggal = trim($_POST['tanggal'] ?? '');
    $kegiatan = trim($_POST['kegiatan'] ?? '');

    if ($tanggal === '' || $kegiatan === '') {
        $error = "Tanggal dan kegiatan wajib diisi.";
    } else {
        $stmt = $conn->prepare("UPDATE jadwal SET tanggal = ?, kegiatan = ? WHERE id_jadwal = ?");
        $stmt->bind_param("ssi", $tanggal, $kegiatan, $id);
        if ($stmt->execute()) {
            $stmt->close();
            header("Location: data.php");
            exit;
        } else {
            $error = "Gagal update data: " . $conn->error;
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Edit Jadwal</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <style>
    body {
      background: linear-gradient(to right, #aed581, #4dd0e1);
      min-height: 100vh;
      font-family: 'Segoe UI', sans-serif;
      padding: 2rem 0;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .form-container {
      background: #fff;
      padding: 2.5rem 3rem;
      border-radius: 1rem;
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
      max-width: 500px;
      width: 100%;
      animation: fadeIn 0.5s ease-in-out;
    }
    @keyframes fadeIn {
      from {opacity: 0; transform: translateY(15px);}
      to {opacity: 1; transform: translateY(0);}
    }
    h2 {
      color: #00695c;
      font-weight: bold;
      margin-bottom: 1.5rem;
      text-align: center;
    }
    .btn-primary, .btn-secondary {
      font-weight: 600;
    }
    .error-message {
      color: #d32f2f;
      font-weight: 600;
      margin-bottom: 1rem;
      text-align: center;
    }
  </style>
</head>
<body>

<div class="form-container">
  <h2><i class="fas fa-calendar-alt me-2"></i>Edit Jadwal</h2>

  <?php if (!empty($error)): ?>
    <div class="error-message"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="post" novalidate>
    <div class="mb-3">
      <label for="tanggal" class="form-label">Tanggal</label>
      <input type="date" id="tanggal" name="tanggal" class="form-control" required
             value="<?= htmlspecialchars($jadwal['tanggal']) ?>">
    </div>
    <div class="mb-3">
      <label for="kegiatan" class="form-label">Kegiatan</label>
      <input type="text" id="kegiatan" name="kegiatan" class="form-control" placeholder="Masukkan kegiatan" required
             value="<?= htmlspecialchars($jadwal['kegiatan']) ?>">
    </div>
    <div class="d-flex justify-content-between">
      <button type="submit" class="btn btn-primary w-50"><i class="fas fa-save me-1"></i>Update</button>
      <a href="data.php" class="btn btn-secondary w-45"><i class="fas fa-arrow-left me-1"></i>Batal</a>
    </div>
  </form>
</div>

</body>
</html>
