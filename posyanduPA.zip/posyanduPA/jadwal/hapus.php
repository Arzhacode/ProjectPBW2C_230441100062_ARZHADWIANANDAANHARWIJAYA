<?php
session_start();
include "../db.php";

if (!isset($_GET['id_jadwal']) || !is_numeric($_GET['id_jadwal'])) {
    die("ID jadwal tidak valid.");
}

$id = (int)$_GET['id_jadwal'];

$stmt = $conn->prepare("DELETE FROM jadwal WHERE id_jadwal = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    $stmt->close();
    header("Location: data.php?msg=delete_success");
    exit;
} else {
    $error = "Gagal menghapus jadwal: " . $conn->error;
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Hapus Jadwal</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
<div class="container py-4">
  <h2>Hapus Jadwal</h2>
  <?php if (isset($error)): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>
  <a href="data.php" class="btn btn-secondary">Kembali</a>
</div>
</body>
</html>
