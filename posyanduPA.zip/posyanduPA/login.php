<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Login Posyandu</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    body {
      min-height: 100vh;
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(135deg, #d4fc79, #96e6a1);
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .login-box {
      background-color: #ffffff;
      padding: 2rem 2.5rem;
      border-radius: 1rem;
      box-shadow: 0 10px 30px rgba(0,0,0,0.1);
      text-align: center;
      max-width: 400px;
      width: 100%;
    }
    .login-box h2 {
      font-weight: 700;
      margin-bottom: 1.5rem;
      color: #2d4d2f;
    }
    .btn-role {
      width: 100%;
      padding: 0.75rem;
      font-weight: 600;
      margin-bottom: 1rem;
      border-radius: 0.6rem;
    }
    .btn-admin {
      background-color: #4CAF50;
      color: white;
    }
    .btn-admin:hover {
      background-color: #45a049;
    }
    .btn-ortu {
      background-color: #007bff;
      color: white;
    }
    .btn-ortu:hover {
      background-color: #0069d9;
    }
    .btn-back {
      background-color: #f9f9f9;
      border: 1px solid #ccc;
      color: #555;
      margin-top: 1rem;
      border-radius: 0.6rem;
      padding: 0.6rem 1rem;
      font-weight: 500;
      text-decoration: none;
      display: inline-block;
    }
    .btn-back:hover {
      background-color: #e6e6e6;
    }
  </style>
</head>
<body>
  <div class="login-box">
    <h2><i class="fas fa-user-lock me-2"></i>Login Sebagai</h2>
    <a href="login_admin.php" class="btn btn-role btn-admin">
      <i class="fas fa-user-shield me-2"></i>Admin
    </a>
    <a href="login_ortu.php" class="btn btn-role btn-ortu">
      <i class="fas fa-user-friends me-2"></i>Orang Tua
    </a>
    <a href="index.php" class="btn-back">
      <i class="fas fa-arrow-left me-1"></i> Kembali ke Beranda
    </a>
  </div>
</body>
</html>
