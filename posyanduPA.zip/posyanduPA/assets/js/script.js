document.addEventListener('DOMContentLoaded', () => {
  console.log('Bootstrap dan Animasi aktif');
});
