<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $username = mysqli_real_escape_string($conn, $_POST['username']);
  $password = $_POST['password'];

  $sql = "SELECT * FROM users WHERE username='$username' AND role='admin'";
  $result = mysqli_query($conn, $sql);

  if (!$result) {
    die("Query error: " . mysqli_error($conn));
  }

  if ($result->num_rows > 0) {
    $user = mysqli_fetch_assoc($result);
    if (password_verify($password, $user['password'])) {
      $_SESSION['admin'] = $username;
      header("Location: dashboard_admin.php");
      exit();
    } else {
      echo "<script>alert('Username atau password salah!');</script>";
    }
  } else {
    echo "<script>alert('Username atau password salah!');</script>";
  }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    body {
      background: linear-gradient(135deg, #d4fc79, #96e6a1);
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      font-family: 'Segoe UI', sans-serif;
    }
    .login-card {
      background: white;
      padding: 2.5rem;
      border-radius: 1rem;
      box-shadow: 0 8px 20px rgba(0,0,0,0.1);
      width: 100%;
      max-width: 400px;
      text-align: center;
    }
    .login-card h3 {
      font-weight: bold;
      color: #2d4d2f;
      margin-bottom: 1.5rem;
    }
    .form-control {
      border-radius: 0.5rem;
      margin-bottom: 1rem;
      padding: 0.75rem;
      font-size: 1rem;
    }
    .btn-login {
      background-color: #4CAF50;
      color: white;
      width: 100%;
      padding: 0.75rem;
      font-weight: 600;
      border-radius: 0.5rem;
      transition: background-color 0.3s ease;
    }
    .btn-login:hover {
      background-color: #45a049;
    }
    .nav-links {
      margin-top: 1.5rem;
      font-size: 0.95rem;
    }
    .nav-links a {
      display: block;
      margin-top: 0.4rem;
      color: #333;
      text-decoration: none;
    }
    .nav-links a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="login-card">
    <h3><i class="fas fa-user-shield me-2"></i>Login Admin</h3>
    <form method="POST">
      <input type="text" name="username" class="form-control" placeholder="Username" required />
      <input type="password" name="password" class="form-control" placeholder="Password" required />
      <button type="submit" class="btn btn-login mt-2">
        <i class="fas fa-sign-in-alt me-1"></i>Masuk
      </button>
    </form>

    <div class="nav-links mt-3">
      <a href="register_admin.php"><i class="fas fa-user-plus me-1"></i>Belum punya akun? Daftar</a>
      <a href="index.php"><i class="fas fa-arrow-left me-1"></i>Kembali ke Beranda</a>
    </div>
  </div>
</body>
</html>
