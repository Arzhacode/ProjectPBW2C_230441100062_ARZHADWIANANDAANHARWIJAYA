<?php
session_start();
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nik = $_POST['nik'];
  $password = md5($_POST['password']); // sesuai dengan hash di DB

  $sql = "SELECT * FROM orangtua WHERE nik='$nik' AND password='$password'";
  $result = $conn->query($sql);

  if ($result && $result->num_rows > 0) {
    $_SESSION['ortu'] = $nik;
    header("Location: dashboard_ortu.php");
    exit;
  } else {
    $error = "NIK atau Password salah!";
  }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login Orangtua</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    body {
      background: linear-gradient(135deg, #c2fcd0, #fceabb);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Segoe UI', sans-serif;
    }

    .login-card {
      background: #fff;
      padding: 2.5rem;
      border-radius: 1rem;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
      max-width: 420px;
      width: 100%;
      text-align: center;
    }

    .login-card h3 {
      font-weight: bold;
      color: #2f4f2f;
      margin-bottom: 1.5rem;
    }

    .form-control {
      padding: 0.75rem;
      border-radius: 0.5rem;
      margin-bottom: 1rem;
      font-size: 1rem;
    }

    .btn-login {
      background: linear-gradient(to right, #76b852, #8DC26F);
      border: none;
      color: white;
      font-weight: 600;
      padding: 0.75rem;
      border-radius: 0.5rem;
      width: 100%;
      transition: background 0.3s ease;
    }

    .btn-login:hover {
      background: linear-gradient(to right, #8DC26F, #76b852);
      transform: translateY(-2px);
    }

    .nav-links {
      margin-top: 1.5rem;
      font-size: 0.95rem;
    }

    .nav-links a {
      color: #333;
      text-decoration: none;
      display: block;
      margin: 0.3rem 0;
    }

    .nav-links a:hover {
      text-decoration: underline;
    }

    .alert {
      margin-bottom: 1rem;
    }
  </style>
</head>
<body>

  <div class="login-card">
    <h3><i class="fas fa-user me-2"></i>Login Orangtua</h3>

    <?php if (isset($error)) : ?>
      <div class="alert alert-danger" role="alert">
        <i class="fas fa-exclamation-triangle me-2"></i><?= $error ?>
      </div>
    <?php endif; ?>

    <form method="POST">
      <input type="text" name="nik" class="form-control" placeholder="Masukkan NIK" required />
      <input type="password" name="password" class="form-control" placeholder="Masukkan Password" required />
      <button type="submit" class="btn btn-login mt-2">
        <i class="fas fa-sign-in-alt me-1"></i>Masuk
      </button>
    </form>

    <div class="nav-links">
      <a href="register_ortu.php"><i class="fas fa-user-plus me-1"></i>Belum punya akun? Daftar</a>
      <a href="index.php"><i class="fas fa-home me-1"></i>Kembali ke Beranda</a>
    </div>
  </div>

</body>
</html>
