-- Buat database
CREATE DATABASE IF NOT EXISTS db_posyandu;
USE db_posyandu;

-- Tabel admin
CREATE TABLE admin (
  id_admin INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  nama_admin VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

-- Tabel orangtua (ortu)
CREATE TABLE orangtua (
  nik VARCHAR(20) PRIMARY KEY,
  nama_ortu VARCHAR(100) NOT NULL,
  password VARCHAR(255) NOT NULL,
  alamat TEXT,
  no_hp VARCHAR(15)
) ENGINE=InnoDB;

-- Tabel anak
CREATE TABLE anak (
  id_anak INT AUTO_INCREMENT PRIMARY KEY,
  nama_anak VARCHAR(100) NOT NULL,
  tanggal_lahir DATE NOT NULL,
  nik_ortu VARCHAR(20) NOT NULL,
  FOREIGN KEY (nik_ortu) REFERENCES orangtua(nik) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Tabel imunisasi
CREATE TABLE imunisasi (
  id_imunisasi INT AUTO_INCREMENT PRIMARY KEY,
  id_anak INT NOT NULL,
  jenis_imunisasi VARCHAR(100) NOT NULL,
  tanggal_imunisasi DATE NOT NULL,
  keterangan TEXT,
  FOREIGN KEY (id_anak) REFERENCES anak(id_anak) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Tabel penimbangan
CREATE TABLE penimbangan (
  id_penimbangan INT AUTO_INCREMENT PRIMARY KEY,
  id_anak INT NOT NULL,
  tanggal DATE NOT NULL,
  berat_badan DECIMAL(5,2) NOT NULL,
  tinggi_badan DECIMAL(5,2) NOT NULL,
  status_gizi VARCHAR(50),
  FOREIGN KEY (id_anak) REFERENCES anak(id_anak) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Tabel jadwal posyandu
CREATE TABLE jadwal (
  id_jadwal INT AUTO_INCREMENT PRIMARY KEY,
  tanggal DATE NOT NULL,
  kegiatan VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

-- Tabel laporan (opsional: rekam ringkasan data)
CREATE TABLE laporan (
  id_laporan INT AUTO_INCREMENT PRIMARY KEY,
  id_anak INT NOT NULL,
  periode VARCHAR(50),
  isi TEXT,
  FOREIGN KEY (id_anak) REFERENCES anak(id_anak) ON DELETE CASCADE
) ENGINE=InnoDB;
