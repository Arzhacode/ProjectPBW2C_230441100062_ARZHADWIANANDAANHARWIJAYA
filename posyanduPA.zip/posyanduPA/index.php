<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Posyandu Sehat</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
  <link rel="stylesheet" href="assets/css/style.css" />
  <style>
    :root {
      --primary-color: #4CAF50; /* Green */
      --secondary-color: #FFC107; /* Amber/Yellow */
      --dark-color: #2E7D32; /* Dark Green */
      --light-color: #F1F8E9; /* Light Green */
      --animation-curve: cubic-bezier(0.65, 0, 0.35, 1);
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      overflow-x: hidden;
      scroll-behavior: smooth;
      background-color: var(--light-color);
    }
    
    .navbar {
      transition: all 0.3s var(--animation-curve);
      padding: 20px 0;
      backdrop-filter: blur(10px);
      background: rgba(255, 255, 255, 0.95) !important;
    }
    
    .navbar.scrolled {
      padding: 10px 0;
      box-shadow: 0 4px 20px rgba(46, 125, 50, 0.1);
      background: rgba(255, 255, 255, 0.98) !important;
    }
    
    .navbar-brand {
      font-weight: 700;
      color: var(--dark-color) !important;
      font-size: 1.5rem;
      transition: all 0.2s var(--animation-curve);
    }
    
    .navbar-brand:hover {
      transform: scale(1.05);
      color: var(--primary-color) !important;
    }
    
    .nav-link {
      font-weight: 500;
      margin: 0 8px;
      position: relative;
      color: var(--dark-color);
      transition: all 0.2s var(--animation-curve);
    }
    
    .nav-link:after {
      content: '';
      position: absolute;
      width: 0;
      height: 2px;
      bottom: 0;
      left: 0;
      background-color: var(--secondary-color);
      transition: width 0.3s var(--animation-curve);
    }
    
    .nav-link:hover {
      transform: translateY(-2px);
      color: var(--primary-color);
    }
    
    .nav-link:hover:after {
      width: 100%;
    }
    
    .hero {
      background: linear-gradient(135deg, var(--primary-color), #8BC34A); /* Green gradient */
      padding: 120px 0 100px;
      color: white;
      position: relative;
      overflow: hidden;
    }
    
    .hero h1 {
      font-weight: 700;
      margin-bottom: 20px;
      text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      line-height: 1.2;
    }
    
    .hero p {
      font-size: 1.2rem;
      opacity: 0.9;
      margin-bottom: 30px;
    }
    
    .hero-img {
      filter: drop-shadow(0 20px 30px rgba(0, 0, 0, 0.2));
      transform-origin: center;
      animation: float 4s var(--animation-curve) infinite;
    }
    
    @keyframes float {
      0%, 100% { transform: translateY(0) rotate(0deg); }
      50% { transform: translateY(-20px) rotate(2deg); }
    }
    
    .hero:before, .hero:after {
      content: '';
      position: absolute;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.1);
      z-index: 0;
      animation: pulse 10s infinite var(--animation-curve);
    }
    
    .hero:before {
      width: 300px;
      height: 300px;
      top: -150px;
      right: -150px;
    }
    
    .hero:after {
      width: 200px;
      height: 200px;
      bottom: -100px;
      left: -100px;
      animation-delay: 0.5s;
    }
    
    @keyframes pulse {
      0%, 100% { transform: scale(1); opacity: 0.1; }
      50% { transform: scale(1.2); opacity: 0.15; }
    }
    
    section {
      padding: 100px 0;
      position: relative;
      overflow: hidden;
    }
    
    .section-title {
      position: relative;
      margin-bottom: 60px;
      font-weight: 700;
      color: var(--dark-color);
      display: inline-block;
    }
    
    .section-title:after {
      content: '';
      position: absolute;
      width: 60px;
      height: 4px;
      background: var(--secondary-color);
      bottom: -15px;
      left: 50%;
      transform: translateX(-50%);
      border-radius: 2px;
    }
    
    .service-card {
      background: white;
      border-radius: 16px;
      padding: 40px 30px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
      transition: all 0.4s var(--animation-curve);
      margin-bottom: 30px;
      text-align: center;
      border: none;
      position: relative;
      overflow: hidden;
      z-index: 1;
    }
    
    .service-card:before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 5px;
      background: var(--secondary-color);
      transform: scaleX(0);
      transform-origin: left;
      transition: transform 0.4s var(--animation-curve);
      z-index: -1;
    }
    
    .service-card:hover {
      transform: translateY(-15px) scale(1.02);
      box-shadow: 0 20px 40px rgba(76, 175, 80, 0.1);
    }
    
    .service-card:hover:before {
      transform: scaleX(1);
    }
    
    .service-icon {
      font-size: 3.5rem;
      color: var(--primary-color);
      margin-bottom: 25px;
      transition: all 0.4s var(--animation-curve);
    }
    
    .service-card:hover .service-icon {
      transform: rotateY(180deg);
      color: var(--secondary-color);
    }
    
    .btn-primary {
      background: var(--primary-color);
      border: none;
      padding: 12px 30px;
      border-radius: 50px;
      font-weight: 500;
      transition: all 0.3s var(--animation-curve);
      position: relative;
      overflow: hidden;
    }
    
    .btn-primary:after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(to right, transparent, rgba(255,255,255,0.3), transparent);
      transform: translateX(-100%);
      transition: transform 0.4s var(--animation-curve);
    }
    
    .btn-primary:hover {
      transform: translateY(-3px);
      box-shadow: 0 10px 20px rgba(76, 175, 80, 0.3);
      background: var(--primary-color);
    }
    
    .btn-primary:hover:after {
      transform: translateX(100%);
    }
    
    .btn-outline-primary {
      border-color: var(--primary-color);
      color: var(--primary-color);
    }
    
    .btn-outline-primary:hover {
      background: var(--primary-color);
      border-color: var(--primary-color);
    }
    
    .contact-info {
      background: white;
      border-radius: 16px;
      padding: 40px 30px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
      transition: all 0.3s var(--animation-curve);
      height: 100%;
      border: 1px solid rgba(0, 0, 0, 0.03);
    }
    
    .contact-info:hover {
      transform: translateY(-10px);
      box-shadow: 0 15px 40px rgba(76, 175, 80, 0.1);
    }
    
    .contact-icon {
      font-size: 2.5rem;
      color: var(--secondary-color);
      margin-bottom: 20px;
      transition: all 0.3s var(--animation-curve);
    }
    
    .contact-info:hover .contact-icon {
      transform: scale(1.2);
    }
    
    footer {
      background: var(--dark-color);
      padding: 60px 0 30px;
      position: relative;
    }
    
    footer:before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 10px;
      background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
    }
    
    .social-links a {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 50px;
      height: 50px;
      border-radius: 50%;
      background: rgba(255,255,255,0.1);
      transition: all 0.3s var(--animation-curve);
      margin-right: 15px;
    }
    
    .social-links a:hover {
      background: var(--secondary-color);
      transform: translateY(-5px) rotate(10deg);
      color: var(--dark-color);
    }
    
    /* Particle background for hero */
    .particles {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 0;
    }
    
    .particle {
      position: absolute;
      background: rgba(255,255,255,0.5);
      border-radius: 50%;
      animation: float-particle linear infinite;
    }
    
    @keyframes float-particle {
      0% { transform: translateY(0) translateX(0); opacity: 0; }
      50% { opacity: 1; }
      100% { transform: translateY(-100vh) translateX(100px); opacity: 0; }
    }
    
    /* Wave divider between sections */
    .wave-divider {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      overflow: hidden;
      line-height: 0;
      transform: rotate(180deg);
    }
    
    .wave-divider svg {
      position: relative;
      display: block;
      width: calc(100% + 1.3px);
      height: 100px;
    }
    
    .wave-divider .shape-fill {
      fill: var(--light-color);
    }
    
    /* Scroll progress indicator */
    .progress-container {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 5px;
      background: transparent;
      z-index: 1000;
    }
    
    .progress-bar {
      height: 5px;
      background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
      width: 0%;
      transition: width 0.1s linear;
    }

    /* Animation adjustments */
    [data-aos] {
      pointer-events: auto;
    }
    .aos-animate {
      opacity: 1 !important;
      transform: none !important;
    }
    
    /* New nature-inspired elements */
    .leaf-decoration {
      position: absolute;
      opacity: 0.1;
      z-index: 0;
    }
    
    .leaf-1 {
      top: 10%;
      left: 5%;
      width: 150px;
      transform: rotate(30deg);
    }
    
    .leaf-2 {
      bottom: 15%;
      right: 5%;
      width: 120px;
      transform: rotate(-20deg);
    }
    
    .bg-light {
      background-color: var(--light-color) !important;
    }
    
    .hover-primary:hover {
      color: var(--primary-color) !important;
    }
    
    .dropdown-menu {
      border: none;
      box-shadow: 0 10px 30px rgba(0,0,0,0.1);
      border-radius: 10px;
    }
    
    .dropdown-item:hover {
      background-color: var(--light-color);
      color: var(--primary-color);
    }
  </style>
</head>
<body>

<!-- Scroll progress indicator -->
<div class="progress-container">
  <div class="progress-bar" id="progressBar"></div>
</div>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light fixed-top">
  <div class="container">
    <a class="navbar-brand" href="#">
      <i class="bi bi-heart-pulse-fill me-2"></i>Posyandu Sehat
    </a>
    <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="#tentang">Tentang Kami</a></li>
        <li class="nav-item"><a class="nav-link" href="#layanan">Layanan</a></li>
        <li class="nav-item"><a class="nav-link" href="#kontak">Kontak</a></li>
        <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
        
        <!-- Dropdown Daftar -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="daftarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Daftar
          </a>
          <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="daftarDropdown">
            <li><a class="dropdown-item" href="register_ortu.php"><i class="bi bi-person-plus me-2"></i>Sebagai Orang Tua</a></li>
            <li><a class="dropdown-item" href="register_admin.php"><i class="bi bi-shield-lock me-2"></i>Sebagai Admin</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero -->
<header class="hero">
  <!-- Particle background -->
  <div class="particles" id="particles"></div>
  
  <!-- Leaf decorations -->
  <img src="https://cdn-icons-png.flaticon.com/512/2909/2909553.png" class="leaf-decoration leaf-1" alt="Leaf decoration">
  <img src="https://cdn-icons-png.flaticon.com/512/2909/2909553.png" class="leaf-decoration leaf-2" alt="Leaf decoration">
  
  <div class="container position-relative" style="z-index: 1;">
    <div class="row align-items-center">
      <div class="col-lg-6" data-aos="fade-right" data-aos-duration="600" data-aos-delay="100">
        <h1 class="display-4 fw-bold mb-4">Selamat Datang di Posyandu Sehat</h1>
        <p class="lead mb-4">Pelayanan kesehatan ibu & anak terbaik dengan pendekatan modern dan ramah keluarga</p>
        <div class="d-flex gap-3">
          <a href="#layanan" class="btn btn-light btn-lg px-4 py-3">Lihat Layanan Kami</a>
          <a href="register_ortu.php" class="btn btn-outline-light btn-lg px-4 py-3">Daftar Sekarang</a>
        </div>
      </div>
      <div class="col-lg-6" data-aos="fade-left" data-aos-duration="600" data-aos-delay="200">
        <img src="https://img.freepik.com/free-vector/happy-family-concept-illustration_114360-8143.jpg" 
             alt="Family Illustration" 
             class="img-fluid hero-img">
      </div>
    </div>
  </div>
  
  <!-- Wave divider -->
  <div class="wave-divider">
    <svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
      <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" class="shape-fill"></path>
    </svg>
  </div>
</header>

<!-- Tentang Kami -->
<section id="tentang" class="bg-white position-relative">
  <div class="container">
    <h2 class="text-center section-title" data-aos="fade-up" data-aos-duration="500">Tentang Kami</h2>
    <div class="row justify-content-center">
      <div class="col-lg-8 text-center" data-aos="fade-up" data-aos-delay="100" data-aos-duration="500">
        <p class="lead mb-5">Posyandu Sehat adalah layanan kesehatan ibu dan anak yang fokus pada tumbuh kembang anak secara menyeluruh melalui program-program berkualitas dengan tenaga kesehatan profesional.</p>
      </div>
    </div>
    <div class="row mt-4">
      <div class="col-md-4" data-aos="fade-up" data-aos-delay="100" data-aos-duration="500">
        <div class="service-card">
          <div class="service-icon">
            <i class="bi bi-people-fill"></i>
          </div>
          <h4 class="fw-bold">10+ Tahun</h4>
          <p>Pengalaman melayani masyarakat</p>
        </div>
      </div>
      <div class="col-md-4" data-aos="fade-up" data-aos-delay="200" data-aos-duration="500">
        <div class="service-card">
          <div class="service-icon">
            <i class="bi bi-heart-fill"></i>
          </div>
          <h4 class="fw-bold">1000+</h4>
          <p>Anak yang telah kami layani</p>
        </div>
      </div>
      <div class="col-md-4" data-aos="fade-up" data-aos-delay="300" data-aos-duration="500">
        <div class="service-card">
          <div class="service-icon">
            <i class="bi bi-award-fill"></i>
          </div>
          <h4 class="fw-bold">Bersertifikat</h4>
          <p>Tenaga kesehatan profesional</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Layanan -->
<section id="layanan" class="bg-light">
  <div class="container">
    <h2 class="text-center section-title" data-aos="fade-up" data-aos-duration="500">Layanan Kami</h2>
    <div class="row">
      <div class="col-md-4" data-aos="fade-up" data-aos-delay="100" data-aos-duration="500">
        <div class="service-card">
          <div class="service-icon">
            <i class="bi bi-people"></i>
          </div>
          <h4 class="fw-bold">Pendaftaran Anak</h4>
          <p>Pendaftaran anak untuk mendapatkan layanan kesehatan berkala dan pemantauan tumbuh kembang.</p>
          <a href="register_ortu.php" class="btn btn-outline-primary mt-3">Daftar Sekarang</a>
        </div>
      </div>
      <div class="col-md-4" data-aos="fade-up" data-aos-delay="200" data-aos-duration="500">
        <div class="service-card">
          <div class="service-icon">
            <i class="bi bi-clipboard2-check"></i>
          </div>
          <h4 class="fw-bold">Imunisasi</h4>
          <p>Layanan imunisasi lengkap sesuai jadwal untuk melindungi anak dari berbagai penyakit berbahaya.</p>
          <a href="#kontak" class="btn btn-outline-primary mt-3">Jadwalkan</a>
        </div>
      </div>
      <div class="col-md-4" data-aos="fade-up" data-aos-delay="300" data-aos-duration="500">
        <div class="service-card">
          <div class="service-icon">
            <i class="bi bi-calendar3"></i>
          </div>
          <h4 class="fw-bold">Jadwal Posyandu</h4>
          <p>Kegiatan posyandu rutin setiap bulan dengan berbagai layanan kesehatan untuk ibu dan anak.</p>
          <a href="#kontak" class="btn btn-outline-primary mt-3">Lihat Jadwal</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Kontak -->
<section id="kontak" class="bg-white">
  <div class="container">
    <h2 class="text-center section-title" data-aos="fade-up" data-aos-duration="500">Kontak Kami</h2>
    <div class="row justify-content-center mt-5">
      <div class="col-lg-8">
        <div class="row">
          <div class="col-md-6" data-aos="fade-up" data-aos-delay="100" data-aos-duration="500">
            <div class="contact-info text-center mb-4">
              <div class="contact-icon">
                <i class="bi bi-geo-alt-fill"></i>
              </div>
              <h4 class="fw-bold">Lokasi</h4>
              <p>Jl. Kesehatan No. 123, Kelurahan Sehat, Kecamatan Bahagia, Kota Bandung</p>
            </div>
          </div>
          <div class="col-md-6" data-aos="fade-up" data-aos-delay="200" data-aos-duration="500">
            <div class="contact-info text-center mb-4">
              <div class="contact-icon">
                <i class="bi bi-telephone-fill"></i>
              </div>
              <h4 class="fw-bold">Telepon</h4>
              <p>(022) 1234567</p>
              <p>0812-3456-7890 (WhatsApp)</p>
            </div>
          </div>
          <div class="col-md-6" data-aos="fade-up" data-aos-delay="300" data-aos-duration="500">
            <div class="contact-info text-center mb-4">
              <div class="contact-icon">
                <i class="bi bi-envelope-fill"></i>
              </div>
              <h4 class="fw-bold">Email</h4>
              <p>info@posyandusehat.com</p>
            </div>
          </div>
          <div class="col-md-6" data-aos="fade-up" data-aos-delay="400" data-aos-duration="500">
            <div class="contact-info text-center mb-4">
              <div class="contact-icon">
                <i class="bi bi-clock-fill"></i>
              </div>
              <h4 class="fw-bold">Jam Operasional</h4>
              <p>Senin-Jumat: 08.00 - 16.00</p>
              <p>Sabtu: 08.00 - 12.00</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Footer -->
<footer class="bg-dark text-white position-relative">
  <div class="container py-5">
    <div class="row">
      <div class="col-lg-4 mb-5 mb-lg-0" data-aos="fade-up" data-aos-duration="500">
        <h4 class="mb-4"><i class="bi bi-heart-pulse-fill me-2"></i>Posyandu Sehat</h4>
        <p class="pe-4">Layanan kesehatan ibu dan anak terbaik dengan pendekatan modern dan ramah keluarga.</p>
      </div>
      <div class="col-lg-2 col-md-4 mb-4 mb-md-0" data-aos="fade-up" data-aos-delay="100" data-aos-duration="500">
        <h5 class="mb-4">Link Cepat</h5>
        <ul class="list-unstyled">
          <li class="mb-2"><a href="#tentang" class="text-white text-decoration-none hover-primary">Tentang Kami</a></li>
          <li class="mb-2"><a href="#layanan" class="text-white text-decoration-none hover-primary">Layanan</a></li>
          <li class="mb-2"><a href="#kontak" class="text-white text-decoration-none hover-primary">Kontak</a></li>
          <li><a href="login.php" class="text-white text-decoration-none hover-primary">Login</a></li>
        </ul>
      </div>
      <div class="col-lg-3 col-md-4 mb-4 mb-md-0" data-aos="fade-up" data-aos-delay="200" data-aos-duration="500">
        <h5 class="mb-4">Layanan</h5>
        <ul class="list-unstyled">
          <li class="mb-2"><a href="register_ortu.php" class="text-white text-decoration-none hover-primary">Pendaftaran Anak</a></li>
          <li class="mb-2"><a href="#layanan" class="text-white text-decoration-none hover-primary">Imunisasi</a></li>
          <li><a href="#kontak" class="text-white text-decoration-none hover-primary">Jadwal Posyandu</a></li>
        </ul>
      </div>
      <div class="col-lg-3 col-md-4" data-aos="fade-up" data-aos-delay="300" data-aos-duration="500">
        <h5 class="mb-4">Sosial Media</h5>
        <div class="social-links">
          <a href="#" class="text-white" data-aos="zoom-in" data-aos-delay="400" data-aos-duration="500"><i class="bi bi-facebook fs-5"></i></a>
          <a href="#" class="text-white" data-aos="zoom-in" data-aos-delay="500" data-aos-duration="500"><i class="bi bi-instagram fs-5"></i></a>
          <a href="#" class="text-white" data-aos="zoom-in" data-aos-delay="600" data-aos-duration="500"><i class="bi bi-twitter-x fs-5"></i></a>
          <a href="#" class="text-white" data-aos="zoom-in" data-aos-delay="700" data-aos-duration="500"><i class="bi bi-youtube fs-5"></i></a>
        </div>
      </div>
    </div>
    <hr class="my-5 bg-light opacity-10">
    <div class="text-center pt-3" data-aos="fade-up" data-aos-duration="500">
      &copy; 2025 Posyandu Sehat. All Rights Reserved.
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
  // Initialize AOS (Animate On Scroll) with persistent animations
  AOS.init({
    duration: 500,
    easing: 'ease-in-out-quad',
    once: false,
    mirror: true,
    disable: false
  });

  window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  });

  // Smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      
      const targetId = this.getAttribute('href');
      const targetElement = document.querySelector(targetId);
      
      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop - 70,
          behavior: 'smooth'
        });
        
        // Close mobile menu if open
        const navbarCollapse = document.querySelector('.navbar-collapse');
        if (navbarCollapse.classList.contains('show')) {
          const toggler = document.querySelector('.navbar-toggler');
          toggler.click();
        }
      }
    });
  });



  // Initialize particles when DOM is loaded
  document.addEventListener('DOMContentLoaded', function() {
    createParticles();
    
    // Add hover effect to service cards
    const serviceCards = document.querySelectorAll('.service-card');
    serviceCards.forEach(card => {
      card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-15px) scale(1.02)';
      });
      
      card.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0) scale(1)';
      });
    });
  });

  // Parallax effect for hero image
  window.addEventListener('scroll', function() {
    const heroImg = document.querySelector('.hero-img');
    if (heroImg) {
      const scrollValue = window.scrollY;
      heroImg.style.transform = `translateY(${scrollValue * 0.2}px) rotate(${scrollValue * 0.02}deg)`;
    }
  });
</script>
</body>
</html>