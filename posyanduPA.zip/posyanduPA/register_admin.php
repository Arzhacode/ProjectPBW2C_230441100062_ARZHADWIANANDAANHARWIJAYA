<?php
// Proses form saat disubmit
if (isset($_POST['register'])) {
    $conn = new mysqli("localhost", "root", "", "db_posyandu");

    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $role = 'admin';

    if (empty($username) || empty($password)) {
        $message = "Username dan password tidak boleh kosong!";
    } else {
        $check = $conn->query("SELECT * FROM users WHERE username='$username'");
        if ($check->num_rows > 0) {
            $message = "Username sudah digunakan. Silakan pilih yang lain.";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO users (username, password, role) VALUES ('$username', '$hashedPassword', '$role')";
            if ($conn->query($sql) === TRUE) {
                $message = "Registrasi berhasil. Silakan login.";
            } else {
                $message = "Gagal menyimpan data: " . $conn->error;
            }
        }
    }

    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Register Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <style>
        :root {
            --gradient-start: #c8facc;
            --gradient-end: #fff9c4;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --text-color: #2c3e50;
            --input-bg: #ffffff;
        }
        body {
            height: 100vh;
            margin: 0;
            font-family: 'Nunito', sans-serif;
            background: linear-gradient(135deg, var(--gradient-start), var(--gradient-end));
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .register-card {
            background: var(--input-bg);
            border-radius: 1rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 420px;
            padding: 2rem 2.5rem;
            animation: fadeInScale 0.6s ease forwards;
            position: relative;
        }
        @keyframes fadeInScale {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
        .card-header {
            text-align: center;
            margin-bottom: 1.5rem;
        }
        .card-header h4 {
            font-weight: 700;
            color: var(--text-color);
        }
        .form-floating input {
            border-radius: 0.5rem;
            padding: 1rem;
        }
        .form-control {
            background-color: var(--input-bg);
            border: 2px solid #ddd;
            font-size: 1rem;
            color: var(--text-color);
        }
        .form-control:focus {
            border-color: #9de27d;
            box-shadow: 0 0 8px #b5f291;
        }
        label {
            color: #666;
            font-weight: 600;
        }
        .password-container {
            position: relative;
        }
        .password-toggle {
            position: absolute;
            top: 50%;
            right: 1rem;
            transform: translateY(-50%);
            cursor: pointer;
            color: #888;
        }
        .btn-primary {
            background: linear-gradient(90deg, #a8e063, #fbc531);
            border: none;
            font-weight: 700;
            padding: 0.75rem;
            border-radius: 0.7rem;
            width: 100%;
        }
        .btn-primary:hover {
            background-position: right center;
            box-shadow: 0 6px 20px rgba(251, 197, 49, 0.4);
        }
        .message {
            margin-bottom: 1rem;
            padding: 1rem 1.5rem;
            border-radius: 0.7rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        .alert-success {
            background-color: rgba(40, 167, 69, 0.15);
            color: var(--success-color);
            border: 1.5px solid var(--success-color);
        }
        .alert-danger {
            background-color: rgba(220, 53, 69, 0.15);
            color: var(--danger-color);
            border: 1.5px solid var(--danger-color);
        }
        .btn-nav {
            padding: 0.6rem 1rem;
            font-weight: 600;
            border-radius: 0.6rem;
            text-decoration: none;
            display: inline-block;
            margin: 0.25rem;
        }
        .btn-login {
            background-color: #d4f6b4;
            color: #2d5f2c;
        }
        .btn-login:hover {
            background-color: #b9e89b;
        }
        .btn-index {
            background-color: #fff3b3;
            color: #735d16;
        }
        .btn-index:hover {
            background-color: #fce996;
        }
    </style>
</head>
<body>
    <div class="register-card shadow">
        <div class="card-header">
            <h4><i class="fas fa-user-shield me-2"></i>Admin Registration</h4>
        </div>
        <?php if (isset($message)): ?>
            <div class="message alert <?php echo strpos($message, 'berhasil') !== false ? 'alert-success' : 'alert-danger'; ?>">
                <i class="fas <?php echo strpos($message, 'berhasil') !== false ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        <form method="POST" action="" class="needs-validation" novalidate>
            <div class="form-floating mb-4">
                <input type="text" class="form-control" id="username" name="username" placeholder="Username" required>
                <label for="username"><i class="fas fa-user me-2"></i>Username</label>
                <div class="invalid-feedback">Please provide a username.</div>
            </div>
            <div class="form-floating mb-4 password-container">
                <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                <label for="password"><i class="fas fa-lock me-2"></i>Password</label>
                <span class="password-toggle" onclick="togglePassword()">
                    <i class="fas fa-eye" id="toggleIcon"></i>
                </span>
                <div class="invalid-feedback">Please provide a password.</div>
            </div>
            <button type="submit" name="register" class="btn btn-primary">
                <i class="fas fa-user-plus me-2"></i>Register
            </button>

            <!-- Navigasi Tambahan -->
            <div class="mt-4 text-center">
                <a href="login.php" class="btn-nav btn-login">
                    <i class="fas fa-sign-in-alt me-1"></i> Login
                </a>
                <a href="index.php" class="btn-nav btn-index">
                    <i class="fas fa-home me-1"></i> Beranda
                </a>
            </div>
        </form>
    </div>

    <!-- JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Bootstrap Validation
        (function () {
            "use strict";
            window.addEventListener("load", function () {
                const forms = document.getElementsByClassName("needs-validation");
                Array.prototype.forEach.call(forms, function (form) {
                    form.addEventListener("submit", function (event) {
                        if (!form.checkValidity()) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add("was-validated");
                    }, false);
                });
            }, false);
        })();

        // Toggle Password
        function togglePassword() {
            const passwordInput = document.getElementById("password");
            const toggleIcon = document.getElementById("toggleIcon");
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                toggleIcon.classList.replace("fa-eye", "fa-eye-slash");
            } else {
                passwordInput.type = "password";
                toggleIcon.classList.replace("fa-eye-slash", "fa-eye");
            }
        }
    </script>
</body>
</html>
