<?php
include "db.php"; // koneksi database

// Ambil data anak
$sql = "SELECT id_anak, nama_anak, tanggal_lahir FROM anak ORDER BY nama_anak ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8" />
<title>Daftar Anak</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
<div class="container py-4">
  <h2>Daftar Anak</h2>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Nama Anak</th>
        <th>Tanggal Lahir</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($row['nama_anak']) ?></td>
            <td><?= date('d-m-Y', strtotime($row['tanggal_lahir'])) ?></td>
            <td>
              <!-- Pakai path absolut supaya pasti diarahkan ke folder kartu -->
              <a href="/kartu/index.php?id_anak=<?= $row['id_anak'] ?>" target="_blank" class="btn btn-primary btn-sm">
                Cetak Kartu
              </a>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="3" class="text-center">Belum ada data anak</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
</body>
</html>
