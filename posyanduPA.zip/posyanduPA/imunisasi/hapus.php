<?php
session_start();
include "../db.php";

$id = $_GET['id'] ?? null;

if ($id) {
    $stmt = $conn->prepare("DELETE FROM imunisasi WHERE id_imunisasi = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}

header("Location: data.php");
exit();
