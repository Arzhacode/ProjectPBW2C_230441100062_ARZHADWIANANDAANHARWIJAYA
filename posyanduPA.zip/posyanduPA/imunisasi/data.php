<?php
session_start();
include "../db.php";

$sql = "SELECT imunisasi.id_imunisasi AS id, imunisasi.jenis_imunisasi AS jenis, imunisasi.tanggal_imunisasi AS tanggal, anak.nama_anak
        FROM imunisasi
        JOIN anak ON imunisasi.id_anak = anak.id_anak
        ORDER BY imunisasi.tanggal_imunisasi DESC";

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Data Imunisasi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <style>
    body {
      background: linear-gradient(to right, #aed581, #4dd0e1);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Segoe UI', sans-serif;
    }
    .data-container {
      background: #ffffff;
      padding: 2rem 2.5rem;
      border-radius: 1rem;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
      max-width: 1000px;
      width: 100%;
      animation: fadeIn 0.5s ease-in-out;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(15px); }
      to { opacity: 1; transform: translateY(0); }
    }
    h2 {
      font-weight: bold;
      color: #00695c;
      text-align: center;
      margin-bottom: 1.5rem;
    }
    .btn {
      font-weight: 600;
    }
    .table thead {
      background-color: #4db6ac;
      color: #fff;
    }
    .table-hover tbody tr:hover {
      background-color: #f1f8e9;
    }
    .table td, .table th {
      text-align: center;
      vertical-align: middle;
    }
  </style>
</head>
<body>

<div class="data-container">
  <h2><i class="fas fa-syringe me-2"></i>Data Imunisasi</h2>

  <div class="d-flex justify-content-between mb-3">
    <a href="tambah.php" class="btn btn-success"><i class="fas fa-plus me-1"></i>Tambah Imunisasi</a>
    <a href="../dashboard_admin.php" class="btn btn-warning text-white"><i class="fas fa-arrow-left me-1"></i>Kembali ke Dashboard</a>
  </div>

  <table class="table table-bordered table-hover">
    <thead>
      <tr>
        <th><i class="fas fa-user"></i> Nama Anak</th>
        <th><i class="fas fa-notes-medical"></i> Jenis Imunisasi</th>
        <th><i class="fas fa-calendar-alt"></i> Tanggal</th>
        <th><i class="fas fa-cogs"></i> Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($row['nama_anak']) ?></td>
        <td><?= htmlspecialchars($row['jenis']) ?></td>
        <td><?= htmlspecialchars($row['tanggal']) ?></td>
        <td>
          <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning text-white" title="Edit">
            <i class="fas fa-edit"></i>
          </a>
          <a href="hapus.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" title="Hapus" onclick="return confirm('Yakin ingin menghapus data ini?')">
            <i class="fas fa-trash-alt"></i>
          </a>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

</body>
</html>
