<?php
session_start();
include "../db.php";

$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: data.php");
    exit();
}

// Ambil data imunisasi yang mau diedit
$stmt = $conn->prepare("SELECT * FROM imunisasi WHERE id_imunisasi = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

if (!$data) {
    header("Location: data.php");
    exit();
}

// Ambil data anak untuk dropdown
$sql_anak = "SELECT id_anak, nama_anak FROM anak ORDER BY nama_anak ASC";
$result_anak = $conn->query($sql_anak);

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_anak = $_POST['id_anak'] ?? '';
    $jenis = $_POST['jenis'] ?? '';
    $tanggal = $_POST['tanggal'] ?? '';

    if ($id_anak && $jenis && $tanggal) {
        $stmt = $conn->prepare("UPDATE imunisasi SET id_anak = ?, jenis_imunisasi = ?, tanggal_imunisasi = ? WHERE id_imunisasi = ?");
        $stmt->bind_param("issi", $id_anak, $jenis, $tanggal, $id);
        if ($stmt->execute()) {
            header("Location: data.php");
            exit();
        } else {
            $error = "Gagal memperbarui data imunisasi.";
        }
    } else {
        $error = "Semua field harus diisi.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Edit Imunisasi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
</head>
<body>
<div class="container mt-5">
  <h2 class="mb-4 text-center text-primary"><i class="fas fa-edit me-2"></i>Edit Imunisasi</h2>

  <?php if ($error): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="POST" action="">
    <div class="mb-3">
      <label for="id_anak" class="form-label">Nama Anak</label>
      <select class="form-select" id="id_anak" name="id_anak" required>
        <option value="" disabled>Pilih Anak</option>
        <?php while ($anak = $result_anak->fetch_assoc()): ?>
          <option value="<?= $anak['id_anak'] ?>" <?= ($data['id_anak'] == $anak['id_anak']) ? 'selected' : '' ?>>
            <?= htmlspecialchars($anak['nama_anak']) ?>
          </option>
        <?php endwhile; ?>
      </select>
    </div>

    <div class="mb-3">
      <label for="jenis" class="form-label">Jenis Imunisasi</label>
      <input type="text" class="form-control" id="jenis" name="jenis" required
        value="<?= htmlspecialchars($data['jenis_imunisasi']) ?>" />
    </div>

    <div class="mb-3">
      <label for="tanggal" class="form-label">Tanggal</label>
      <input type="date" class="form-control" id="tanggal" name="tanggal" required
        value="<?= htmlspecialchars($data['tanggal_imunisasi']) ?>" />
    </div>

    <button type="submit" class="btn btn-primary w-100"><i class="fas fa-save me-1"></i>Update</button>
  </form>

  <div class="mt-3 text-center">
    <a href="data.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Kembali ke Data Imunisasi</a>
  </div>
</div>
</body>
</html>
