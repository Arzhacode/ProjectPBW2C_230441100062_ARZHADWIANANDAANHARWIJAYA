<?php
session_start();
include "../db.php";

$sql_anak = "SELECT id_anak, nama_anak FROM anak ORDER BY nama_anak ASC";
$result_anak = $conn->query($sql_anak);

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_anak = $_POST['id_anak'] ?? '';
    $jenis = $_POST['jenis'] ?? '';
    $tanggal = $_POST['tanggal'] ?? '';

    if ($id_anak && $jenis && $tanggal) {
        $stmt = $conn->prepare("INSERT INTO imunisasi (id_anak, jenis_imunisasi, tanggal_imunisasi) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $id_anak, $jenis, $tanggal);
        if ($stmt->execute()) {
            header("Location: data.php"); // Redirect ke halaman data.php
            exit();
        } else {
            $error = "Gagal menyimpan data imunisasi.";
        }
    } else {
        $error = "Semua field harus diisi.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Tambah Imunisasi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <style>
    body {
      background: linear-gradient(to right, #aed581, #4dd0e1);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Segoe UI', sans-serif;
    }
    .form-container {
      background: #ffffff;
      padding: 2rem 2.5rem;
      border-radius: 1rem;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
      max-width: 500px;
      width: 100%;
      animation: fadeIn 0.5s ease-in-out;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(15px); }
      to { opacity: 1; transform: translateY(0); }
    }
    h2 {
      font-weight: bold;
      color: #00695c;
      text-align: center;
      margin-bottom: 1.5rem;
    }
    label {
      font-weight: 600;
    }
    .btn-submit {
      font-weight: 600;
    }
    .error-message {
      color: #d32f2f;
      font-weight: 600;
      margin-bottom: 1rem;
      text-align: center;
    }
  </style>
</head>
<body>

<div class="form-container">
  <h2><i class="fas fa-plus me-2"></i>Tambah Imunisasi</h2>

  <?php if ($error): ?>
    <div class="error-message"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="POST" action="">
    <div class="mb-3">
      <label for="id_anak" class="form-label">Nama Anak</label>
      <select class="form-select" id="id_anak" name="id_anak" required>
        <option value="" selected disabled>Pilih Anak</option>
        <?php while ($anak = $result_anak->fetch_assoc()): ?>
          <option value="<?= $anak['id_anak'] ?>" <?= (isset($id_anak) && $id_anak == $anak['id_anak']) ? 'selected' : '' ?>>
            <?= htmlspecialchars($anak['nama_anak']) ?>
          </option>
        <?php endwhile; ?>
      </select>
    </div>

    <div class="mb-3">
      <label for="jenis" class="form-label">Jenis Imunisasi</label>
      <input type="text" class="form-control" id="jenis" name="jenis" placeholder="Contoh: Polio, DPT" required
        value="<?= isset($jenis) ? htmlspecialchars($jenis) : '' ?>" />
    </div>

    <div class="mb-3">
      <label for="tanggal" class="form-label">Tanggal</label>
      <input type="date" class="form-control" id="tanggal" name="tanggal" required
        value="<?= isset($tanggal) ? htmlspecialchars($tanggal) : '' ?>" />
    </div>

    <button type="submit" class="btn btn-success w-100 btn-submit"><i class="fas fa-save me-1"></i>Simpan</button>
  </form>

  <div class="mt-3 text-center">
    <a href="data.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Kembali ke Data Imunisasi</a>
  </div>
</div>

</body>
</html>
