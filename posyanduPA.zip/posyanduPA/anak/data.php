<?php
session_start();
include "../db.php";

if (!isset($_SESSION['ortu'])) {
  header("Location: ../login_ortu.php");
  exit;
}

$nik_ortu = $_SESSION['ortu'];
$sql = "SELECT * FROM anak WHERE nik_ortu='$nik_ortu'";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Data Anak</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <style>
    body {
      background: linear-gradient(to right, #4dd0e1, #fff176);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Segoe UI', sans-serif;
    }

    .data-container {
      background: #ffffff;
      padding: 2rem 2.5rem;
      border-radius: 1rem;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
      max-width: 1000px;
      width: 100%;
      animation: fadeIn 0.6s ease-in-out;
    }

    .data-container h2 {
      font-weight: 700;
      color: #00796b;
      margin-bottom: 1.5rem;
      text-align: center;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .btn {
      font-weight: 600;
    }

    .table thead {
      background-color: #4db6ac;
      color: #fff;
    }

    .table-hover tbody tr:hover {
      background-color: #f1f8e9;
    }

    .table td, .table th {
      vertical-align: middle;
      text-align: center;
    }

    .table-icon {
      margin-right: 6px;
    }
  </style>
</head>
<body>

<div class="data-container">
  <h2><i class="fas fa-children me-2"></i>Data Anak</h2>

  <div class="d-flex justify-content-between mb-3">
    <a href="tambah.php" class="btn btn-success"><i class="fas fa-plus me-1"></i>Tambah Anak</a>
    <a href="../dashboard_ortu.php" class="btn btn-warning text-white"><i class="fas fa-arrow-left me-1"></i>Kembali ke Dashboard</a>
  </div>

  <table class="table table-bordered table-hover">
    <thead>
      <tr>
        <th><i class="fas fa-id-badge table-icon"></i>ID Anak</th>
        <th><i class="fas fa-user table-icon"></i>Nama Anak</th>
        <th><i class="fas fa-calendar-alt table-icon"></i>Tanggal Lahir</th>
        <th><i class="fas fa-cogs table-icon"></i>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
          <td><?= htmlspecialchars($row['id_anak']); ?></td>
          <td><?= htmlspecialchars($row['nama_anak']); ?></td>
          <td><?= htmlspecialchars($row['tanggal_lahir']); ?></td>
          <td>
            <a href="../kartu/index.php?id_anak=<?= urlencode($row['id_anak']); ?>" target="_blank" class="btn btn-sm btn-info text-white">
              <i class="fas fa-id-card"></i> Kartu
            </a>
            <a href="edit.php?id_anak=<?= urlencode($row['id_anak']); ?>" class="btn btn-sm btn-warning text-white">
              <i class="fas fa-edit"></i> Edit
            </a>
          </td>
        </tr>
      <?php } ?>
    </tbody>
  </table>
</div>

</body>
</html>
