<?php
include "../db.php";
$id = $_GET['id'];
$sql = "DELETE FROM anak WHERE id='$id'";
$conn->query($sql);
header("Location: data.php");
?>
