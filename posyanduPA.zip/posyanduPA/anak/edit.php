<?php
session_start();
include "../db.php";

if (!isset($_GET['id_anak']) || !is_numeric($_GET['id_anak'])) {
    die("ID anak tidak valid.");
}

$id = (int)$_GET['id_anak'];

// Ambil data anak berdasarkan id_anak
$stmt = $conn->prepare("SELECT * FROM anak WHERE id_anak = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$stmt->close();

if (!$row) {
    die("Data anak tidak ditemukan.");
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = trim($_POST['nama'] ?? '');
    $tgl_lahir = trim($_POST['tgl_lahir'] ?? '');

    if ($nama === '' || $tgl_lahir === '') {
        $error = "Nama dan tanggal lahir wajib diisi.";
    } else {
        $stmt = $conn->prepare("UPDATE anak SET nama_anak = ?, tanggal_lahir = ? WHERE id_anak = ?");
        $stmt->bind_param("ssi", $nama, $tgl_lahir, $id);
        if ($stmt->execute()) {
            $stmt->close();
            header("Location: data.php");
            exit;
        } else {
            $error = "Gagal update data!";
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Data Anak</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-4">
  <h2>Edit Data Anak</h2>
  <?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>
  <form method="post">
    <div class="mb-3">
      <label for="nama" class="form-label">Nama Anak</label>
      <input type="text" id="nama" name="nama" value="<?= htmlspecialchars($row['nama_anak']) ?>" class="form-control" required>
    </div>
    <div class="mb-3">
      <label for="tgl_lahir" class="form-label">Tanggal Lahir</label>
      <input type="date" id="tgl_lahir" name="tgl_lahir" value="<?= htmlspecialchars($row['tanggal_lahir']) ?>" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-success">Update</button>
    <a href="data.php" class="btn btn-secondary">Kembali</a>
  </form>
</div>
</body>
</html>
