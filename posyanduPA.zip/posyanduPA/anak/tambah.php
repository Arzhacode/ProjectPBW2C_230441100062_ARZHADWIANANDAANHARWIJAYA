<?php
session_start();
include "../db.php";

if (!isset($_SESSION['ortu'])) {
  header("Location: ../login_ortu.php");
  exit;
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nama = trim($_POST['nama'] ?? '');
  $tgl_lahir = $_POST['tgl_lahir'] ?? '';
  $nik_ortu = $_SESSION['ortu'];

  if (!$nama || !$tgl_lahir) {
    $error = "Semua field harus diisi.";
  } else {
    $stmt = $conn->prepare("INSERT INTO anak (nama_anak, tanggal_lahir, nik_ortu) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $nama, $tgl_lahir, $nik_ortu);

    if ($stmt->execute()) {
      header("Location: data.php");
      exit;
    } else {
      $error = "Gagal tambah data: " . $conn->error;
    }
  }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Tambah Data Anak</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      background: linear-gradient(to right, #aed581, #4dd0e1);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Segoe UI', sans-serif;
    }
    .form-container {
      background: #ffffff;
      padding: 2rem 2.5rem;
      border-radius: 1rem;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
      max-width: 500px;
      width: 100%;
      animation: fadeIn 0.5s ease-in-out;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(15px); }
      to { opacity: 1; transform: translateY(0); }
    }
    h2 {
      font-weight: bold;
      color: #00695c;
      text-align: center;
      margin-bottom: 1.5rem;
    }
    .btn {
      font-weight: 600;
    }
  </style>
</head>
<body>
  <div class="form-container">
    <h2><i class="fas fa-child me-2"></i>Tambah Data Anak</h2>
    <?php if ($error): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post" novalidate>
      <div class="mb-3">
        <input type="text" name="nama" placeholder="Nama Anak" class="form-control" required
               value="<?= isset($nama) ? htmlspecialchars($nama) : '' ?>">
      </div>
      <div class="mb-3">
        <input type="date" name="tgl_lahir" class="form-control" required
               value="<?= isset($tgl_lahir) ? htmlspecialchars($tgl_lahir) : '' ?>">
      </div>
      <div class="d-flex justify-content-between">
        <button type="submit" class="btn btn-success w-50"><i class="fas fa-save me-1"></i>Simpan</button>
        <a href="data.php" class="btn btn-secondary w-45"><i class="fas fa-arrow-left me-1"></i>Kembali</a>
      </div>
    </form>
  </div>

  <!-- FontAwesome CDN for icons -->
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>
