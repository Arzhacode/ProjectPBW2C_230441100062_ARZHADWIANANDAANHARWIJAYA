<?php
session_start();
include "../db.php";

$res = $conn->query("
  SELECT 
    p.id_penimbangan, 
    a.id_anak,
    a.nama_anak AS anak, 
    p.tanggal AS berat_tgl,
    p.berat_badan AS berat, 
    p.tinggi_badan AS tinggi,
    p.status_gizi,
    im.tanggal_imunisasi AS imun_tgl, 
    im.jenis_imunisasi AS jenis,
    j.tanggal AS jadwal_tgl,
    j.kegiatan AS kegiatan
  FROM penimbangan p
  LEFT JOIN anak a ON p.id_anak = a.id_anak
  LEFT JOIN imunisasi im ON im.id_anak = a.id_anak
  LEFT JOIN jadwal j ON DATE(im.tanggal_imunisasi) = DATE(j.tanggal)
  ORDER BY p.tanggal DESC
");

if (!$res) {
    die("Query Error: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Laporan Posyandu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    body {
      background: linear-gradient(to right, #a1c4fd, #c2e9fb);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Segoe UI', sans-serif;
    }
    .data-container {
      background: #ffffff;
      padding: 2rem 2.5rem;
      border-radius: 1rem;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
      max-width: 1200px;
      width: 100%;
      animation: fadeIn 0.5s ease-in-out;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(15px); }
      to { opacity: 1; transform: translateY(0); }
    }
    h2 {
      font-weight: bold;
      color: #00695c;
      text-align: center;
      margin-bottom: 1.5rem;
    }
    .btn {
      font-weight: 600;
    }
    .table thead {
      background-color: #26a69a;
      color: #fff;
    }
    .table-hover tbody tr:hover {
      background-color: #f1f8e9;
    }
    .table td, .table th {
      text-align: center;
      vertical-align: middle;
      font-size: 14px;
    }
  </style>
</head>
<body>

<div class="data-container">
  <h2><i class="fas fa-file-medical-alt me-2"></i>Laporan Posyandu</h2>

  <div class="d-flex justify-content-between mb-3">
    <a href="../dashboard_admin.php" class="btn btn-warning text-white"><i class="fas fa-arrow-left me-1"></i>Kembali ke Dashboard</a>
    <a href="cetak.php" class="btn btn-primary"><i class="fas fa-print me-1"></i>Cetak PDF Laporan</a>
  </div>

  <table class="table table-bordered table-hover">
    <thead>
      <tr>
        <th>Nama Anak</th>
        <th>Tgl Timbang</th>
        <th>Berat (kg)</th>
        <th>Tinggi (cm)</th>
        <th>Status Gizi</th>
        <th>Tgl Imunisasi</th>
        <th>Jenis Imunisasi</th>
        <th>Jadwal Posyandu</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($r = $res->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($r['anak']) ?></td>
        <td><?= htmlspecialchars($r['berat_tgl']) ?></td>
        <td><?= htmlspecialchars($r['berat']) ?></td>
        <td><?= htmlspecialchars($r['tinggi']) ?></td>
        <td><?= htmlspecialchars($r['status_gizi'] ?? '-') ?></td>
        <td><?= htmlspecialchars($r['imun_tgl']) ?? '-' ?></td>
        <td><?= htmlspecialchars($r['jenis']) ?? '-' ?></td>
        <td><?= htmlspecialchars($r['jadwal_tgl']) ?> - <?= htmlspecialchars($r['kegiatan']) ?></td>
        <td>
          <a href="../kartu/index.php?id_anak=<?= urlencode($r['id_anak']) ?>" target="_blank" class="btn btn-sm btn-success">
            <i class="fas fa-id-card-alt me-1"></i> Cetak Kartu
          </a>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

</body>
</html>
