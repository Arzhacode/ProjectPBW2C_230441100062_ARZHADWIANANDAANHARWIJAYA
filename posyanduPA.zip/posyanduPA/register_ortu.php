<?php
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nik = $_POST['nik'];
    $nama = $_POST['nama'];
    $password = $_POST['password'];

    if (strlen($password) < 4 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $error = "Password minimal 4 karakter dan harus mengandung huruf & angka!";
    } else {
        $hash = md5($password); // Encrypt

        $cek = $conn->query("SELECT * FROM orangtua WHERE nik='$nik'");
        if ($cek->num_rows > 0) {
            $error = "NIK sudah terdaftar!";
        } else {
            $sql = "INSERT INTO orangtua (nik, nama_ortu, password) VALUES ('$nik', '$nama', '$hash')";
            if ($conn->query($sql) === TRUE) {
                header("Location: login_ortu.php?msg=daftar_berhasil");
                exit();
            } else {
                $error = "Gagal daftar! " . $conn->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Daftar Orang Tua</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    :root {
      --gradient-start: #c7f0a7;
      --gradient-end: #fff5b1;
      --input-bg: #fffefc;
      --text-color: #2c3e50;
      --danger-color: #dc3545;
    }

    body {
      min-height: 100vh;
      background: linear-gradient(135deg, var(--gradient-start), var(--gradient-end));
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Segoe UI', sans-serif;
    }

    .card-register {
      width: 100%;
      max-width: 420px;
      background: white;
      border-radius: 15px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.1);
      padding: 2rem;
      animation: fadeIn 0.6s ease-out;
    }

    .form-control {
      border-radius: 0.5rem;
      background: var(--input-bg);
    }

    .btn-success {
      background: linear-gradient(90deg, #b4e197, #f6eca9);
      color: #3a5a21;
      border: none;
      transition: all 0.3s ease-in-out;
    }

    .btn-success:hover {
      background: linear-gradient(90deg, #a0d37f, #f0e47f);
      color: #2c4717;
      transform: translateY(-2px);
    }

    .nav-link {
      display: inline-block;
      margin: 5px 10px;
      text-decoration: none;
      padding: 10px 15px;
      border-radius: 8px;
      font-weight: 500;
      transition: all 0.3s;
    }

    .nav-login {
      background: linear-gradient(90deg, #b4e197, #d7f1a1);
      color: #3a5a21;
    }

    .nav-login:hover {
      background: linear-gradient(90deg, #a0d37f, #c7e88c);
      color: #2c4717;
      transform: translateY(-2px);
    }

    .nav-index {
      background: linear-gradient(90deg, #fff7b3, #fffed1);
      color: #6a6a36;
    }

    .nav-index:hover {
      background: linear-gradient(90deg, #f4ec90, #fff9a3);
      color: #5a5a29;
      transform: translateY(-2px);
    }

    .alert-danger {
      background-color: rgba(220, 53, 69, 0.1);
      color: var(--danger-color);
      border: 1px solid rgba(220, 53, 69, 0.2);
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
  </style>
</head>
<body>
  <div class="card-register">
    <h4 class="mb-4 text-center text-success fw-bold">Daftar Orang Tua</h4>

    <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

    <form method="post" novalidate>
      <div class="mb-3">
        <input type="text" name="nik" placeholder="NIK" class="form-control" required>
      </div>
      <div class="mb-3">
        <input type="text" name="nama" placeholder="Nama Lengkap" class="form-control" required>
      </div>
      <div class="mb-3">
        <input type="password" name="password" placeholder="Password" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-success w-100">Daftar</button>
    </form>

    <!-- Navigasi bawah -->
    <div class="mt-4 text-center">
      <a href="login.php" class="nav-link nav-login">🔐 Login</a>
      <a href="index.php" class="nav-link nav-index">🏠 Kembali ke Beranda</a>
    </div>
  </div>
</body>
</html>
