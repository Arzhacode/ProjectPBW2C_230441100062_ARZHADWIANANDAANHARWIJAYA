<?php
session_start();
if (!isset($_SESSION['admin'])) {
  header("Location: login_admin.php");
  exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Dashboard Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <style>
    body {
      background: linear-gradient(to right, #e0f7fa, #fffde7);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Segoe UI', sans-serif;
    }

    .dashboard-container {
      background: #ffffff;
      padding: 2rem 2.5rem;
      border-radius: 1rem;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
      max-width: 800px;
      width: 100%;
    }

    .dashboard-container h1 {
      font-weight: 700;
      color: #2c3e50;
      margin-bottom: 1rem;
      text-align: center;
    }

    .welcome {
      text-align: center;
      margin-bottom: 2rem;
      font-size: 1.1rem;
      color: #555;
    }

    .btn-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 1rem;
      margin-bottom: 1.5rem;
    }

    .btn {
      font-weight: 600;
      padding: 0.75rem 1rem;
    }

    .back-link {
      text-align: center;
    }

    .back-link a {
      text-decoration: none;
      color: #555;
      font-weight: 500;
    }

    .back-link a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="dashboard-container">
  <h1><i class="fas fa-user-shield me-2"></i>Dashboard Admin</h1>
  <div class="welcome">
    Selamat datang, <strong><?= $_SESSION['admin'] ?></strong>!
  </div>

  <div class="btn-grid">
    <a href="anak/data.php" class="btn btn-outline-primary"><i class="fas fa-child me-2"></i>Data Anak</a>
    <a href="imunisasi/data.php" class="btn btn-outline-success"><i class="fas fa-syringe me-2"></i>Imunisasi</a>
    <a href="penimbangan/data.php" class="btn btn-outline-warning"><i class="fas fa-weight me-2"></i>Penimbangan</a>
    <a href="jadwal/data.php" class="btn btn-outline-info"><i class="fas fa-calendar-alt me-2"></i>Jadwal</a>
    <a href="laporan/data.php" class="btn btn-outline-secondary"><i class="fas fa-file-alt me-2"></i>Laporan</a>
    <a href="kartu/index.php" class="btn btn-outline-dark"><i class="fas fa-id-card me-2"></i>Cetak Kartu Anak</a>
    <a href="logout.php" class="btn btn-outline-danger"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
  </div>

  <div class="back-link">
    <a href="index.php"><i class="fas fa-arrow-left me-1"></i>Kembali ke Halaman Utama</a>
  </div>
</div>

</body>
</html>
