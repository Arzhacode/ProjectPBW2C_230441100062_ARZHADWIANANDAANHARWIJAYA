<?php
session_start();
if (!isset($_SESSION['ortu'])) {
  header("Location: login_ortu.php");
  exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Dashboard Orangtua</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <style>
    body {
      background: linear-gradient(to right, #fdfbfb, #ebedee);
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
    }

    .dashboard {
      background-color: #fff;
      padding: 2rem 2.5rem;
      border-radius: 1rem;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
      max-width: 600px;
      width: 100%;
    }

    h2 {
      text-align: center;
      font-weight: 700;
      color: #2c3e50;
      margin-bottom: 1.5rem;
    }

    .btn-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 1rem;
      margin-bottom: 1.5rem;
    }

    .btn {
      font-weight: 600;
      padding: 0.75rem 1rem;
    }

    .back-link {
      text-align: center;
      margin-top: 1rem;
    }

    .back-link a {
      text-decoration: none;
      color: #555;
      font-weight: 500;
    }

    .back-link a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="dashboard">
  <h2><i class="fas fa-user-friends me-2"></i>Dashboard Orangtua</h2>
  <div class="btn-grid">
    <a href="anak/tambah.php" class="btn btn-outline-success">
      <i class="fas fa-plus-circle me-2"></i>Tambah Anak
    </a>
    <a href="anak/data.php" class="btn btn-outline-info">
      <i class="fas fa-list me-2"></i>Data Anak
    </a>
    <a href="logout.php" class="btn btn-outline-danger">
      <i class="fas fa-sign-out-alt me-2"></i>Logout
    </a>
  </div>

  <div class="back-link">
    <a href="index.php"><i class="fas fa-arrow-left me-1"></i>Kembali ke Halaman Utama</a>
  </div>
</div>

</body>
</html>
