<?php
require '../vendor/autoload.php';
use Dompdf\Dompdf;
use Dompdf\Options;

include "../db.php";

$id_anak = isset($_GET['id_anak']) ? (int)$_GET['id_anak'] : 0;
if ($id_anak <= 0) die("ID anak tidak valid.");

// Data anak dan ortu
$stmt = $conn->prepare("
    SELECT a.nama_anak, a.tanggal_lahir, o.nama_ortu, o.no_hp, o.alamat
    FROM anak a
    JOIN orangtua o ON a.nik_ortu = o.nik
    WHERE a.id_anak = ?
");
$stmt->bind_param("i", $id_anak);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$data) die("Data anak tidak ditemukan.");

// Imunisasi terakhir
$stmt = $conn->prepare("
    SELECT jenis_imunisasi, tanggal_imunisasi
    FROM imunisasi
    WHERE id_anak = ?
    ORDER BY tanggal_imunisasi DESC LIMIT 1
");
$stmt->bind_param("i", $id_anak);
$stmt->execute();
$imun = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Penimbangan terakhir
$stmt = $conn->prepare("
    SELECT berat_badan, tinggi_badan, tanggal, status_gizi
    FROM penimbangan
    WHERE id_anak = ?
    ORDER BY tanggal DESC LIMIT 1
");
$stmt->bind_param("i", $id_anak);
$stmt->execute();
$timbang = $stmt->get_result()->fetch_assoc();
$stmt->close();

function safe($str) {
    return htmlspecialchars($str ?? '-');
}

$tgl_lahir = !empty($data['tanggal_lahir']) ? date('d-m-Y', strtotime($data['tanggal_lahir'])) : '-';
$tgl_imun = !empty($imun['tanggal_imunisasi']) ? date('d-m-Y', strtotime($imun['tanggal_imunisasi'])) : '-';

$html = '
<style>
  @page { margin: 0; }
  body {
    font-family: Arial, sans-serif;
    margin: 0; padding: 0;
    background-color: #f8f9fa;
  }
  .card {
    width: 86mm; height: 54mm;
    background: #fff;
    border: 1px solid #ccc;
    border-radius: 6px;
    padding: 6mm;
    box-sizing: border-box;
    position: relative;
    page-break-after: always;
  }
  .header {
    background: #2e86de;
    color: #fff;
    font-weight: bold;
    text-align: center;
    padding: 3px;
    border-radius: 4px;
    font-size: 11pt;
    margin-bottom: 5px;
  }
  table {
    width: 100%;
    font-size: 8.8pt;
    line-height: 1.3;
  }
  td { vertical-align: top; padding: 1px 0; }
  .label { width: 34%; font-weight: bold; color: #444; }
  .value { width: 66%; }
  .footer {
    position: absolute;
    bottom: 6mm;
    right: 6mm;
    text-align: right;
    font-size: 8pt;
    color: #333;
  }
  .footer strong {
    display: inline-block;
    margin-top: 3px;
    border-top: 1px solid #333;
    padding-top: 1px;
  }
</style>

<!-- Kartu Identitas -->
<div class="card">
  <div class="header">KARTU KESEHATAN ANAK</div>
  <table>
    <tr><td class="label">Nama Anak</td><td class="value">: '.safe($data['nama_anak']).'</td></tr>
    <tr><td class="label">Tgl Lahir</td><td class="value">: '.$tgl_lahir.'</td></tr>
    <tr><td class="label">Nama Ortu</td><td class="value">: '.safe($data['nama_ortu']).'</td></tr>
    <tr><td class="label">No HP</td><td class="value">: '.safe($data['no_hp']).'</td></tr>
    <tr><td class="label">Alamat</td><td class="value">: '.safe($data['alamat']).'</td></tr>
  </table>
  <div class="footer">
    Ditetapkan oleh<br><strong>dr. FEAR</strong>
  </div>
</div>

<!-- Kartu Kesehatan -->
<div class="card">
  <div class="header">INFORMASI KESEHATAN TERBARU</div>
  <table>
    <tr><td class="label">Berat Badan</td><td class="value">: '.(isset($timbang['berat_badan']) ? $timbang['berat_badan'] . " kg" : "-").'</td></tr>
    <tr><td class="label">Tinggi Badan</td><td class="value">: '.(isset($timbang['tinggi_badan']) ? $timbang['tinggi_badan'] . " cm" : "-").'</td></tr>
    <tr><td class="label">Status Gizi</td><td class="value">: '.($timbang['status_gizi'] ?? '-').'</td></tr>
    <tr><td class="label">Imunisasi</td><td class="value">: '.($imun['jenis_imunisasi'] ?? '-').'</td></tr>
    <tr><td class="label">Tgl Imunisasi</td><td class="value">: '.$tgl_imun.'</td></tr>
  </table>
  <div class="footer">
    Disahkan oleh<br><strong>dr. FEAR</strong>
  </div>
</div>
';

$options = new Options();
$options->setIsRemoteEnabled(true);
$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);

// Ukuran 86mm x 54mm (dpi = 72, 1 inch = 25.4mm, 1mm = 2.83465pt)
$dompdf->setPaper([0, 0, 86 * 2.83465, 54 * 2.83465], 'portrait');
$dompdf->render();
$dompdf->stream("kartu_kesehatan_anak_$id_anak.pdf", ["Attachment" => false]);

exit;
